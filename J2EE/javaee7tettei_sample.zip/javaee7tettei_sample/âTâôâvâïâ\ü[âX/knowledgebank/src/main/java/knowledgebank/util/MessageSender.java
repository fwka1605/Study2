package knowledgebank.util;

public class MessageSender {
    
}
