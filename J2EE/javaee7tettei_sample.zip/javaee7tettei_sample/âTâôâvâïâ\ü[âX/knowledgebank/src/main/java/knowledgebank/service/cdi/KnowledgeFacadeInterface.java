package knowledgebank.service.cdi;

public interface KnowledgeFacadeInterface {
    
}
