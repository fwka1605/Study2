package sb;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/rs")
public class SimpleBatchApplication extends Application {
    // 実装は特になし.
}
