package com.kayosystem.honki.chapter02.lesson07;

/**
 * Created by Re:Kayo-System on 2016/09/29.
 */

public class User {
    long id;
    String name;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
