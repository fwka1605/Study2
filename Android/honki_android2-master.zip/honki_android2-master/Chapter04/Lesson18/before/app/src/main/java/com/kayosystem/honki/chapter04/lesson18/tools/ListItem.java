package com.kayosystem.honki.chapter04.lesson18.tools;

import android.net.Uri;

public class ListItem {
    private int mId;
    private String mName;

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        mId = id;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }
}
